var searchData=
[
  ['height',['height',['../classstack_matrix.html#a3dcbce1916322eca6cb2f835bbe0f355',1,'stackMatrix']]]
];
