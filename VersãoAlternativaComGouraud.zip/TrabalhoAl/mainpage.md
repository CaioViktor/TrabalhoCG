/// \mainpage
# Trabalho de Computação Gráfica
## Computação-UFC
###Equipe:

- Caio Viktor
- Cristiano Melo
- Geraldo Braz
- Lucas Falcão
- Matheus Mayron

- - - - - -
### A aplicação central, o main, está aqui: main.cpp

### As classes estão listadas na aba Classes.

OBS: Os comentários feitos em main.cpp não são visualizados nesta versão. Caso queira vê-los, é necessário que abra o arquivo em algum editor de texto.
OBS2: Tentaremos consertar a "Feature" acima na próxima versão.