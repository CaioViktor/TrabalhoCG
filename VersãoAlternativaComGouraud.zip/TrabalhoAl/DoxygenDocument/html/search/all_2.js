var searchData=
[
  ['canceltransformation',['cancelTransformation',['../main_8cpp.html#ae7e1943b8013b4027407331a3ce9393d',1,'main.cpp']]],
  ['centroid',['centroid',['../class_object_class.html#a9d1f9761df7afaa30df99c563854755f',1,'ObjectClass']]],
  ['centrox',['centrox',['../main_8cpp.html#aefbc9802f3f5486bc4c53cde32c75311',1,'main.cpp']]],
  ['centroy',['centroy',['../main_8cpp.html#a6f30c3959c42785a3f826d8ef4377d1b',1,'main.cpp']]],
  ['centroz',['centroz',['../main_8cpp.html#a996376214452b594bca242c4cec445c8',1,'main.cpp']]],
  ['colorb',['colorB',['../main_8cpp.html#a45b7c578ae3f16efe932dbb492e0c241',1,'main.cpp']]],
  ['colorg',['colorG',['../main_8cpp.html#a4b973d67a4b64123f4656a0025c540d9',1,'main.cpp']]],
  ['colorr',['colorR',['../main_8cpp.html#a00e131a13f69b1baa5202e1386b2caf0',1,'main.cpp']]],
  ['concatenate',['concatenate',['../classstack_matrix.html#a35ac7d3bf630484f5b9735b6e7c355fc',1,'stackMatrix']]],
  ['confirmtransformation',['confirmTransformation',['../main_8cpp.html#a9141f125266c65b4bdd54dc2075d6b5b',1,'main.cpp']]],
  ['content',['content',['../class_matrix.html#a0c2a72a55b5b9a9b6f592420eb0120b5',1,'Matrix::content()'],['../struct_no__.html#a80653e07ba702dd2d07d3c36de0afad7',1,'No_::content()']]],
  ['coordinatex',['coordinateX',['../main_8cpp.html#a75d38e822fcd0ab96ab329208a2c72de',1,'main.cpp']]],
  ['coordinatey',['coordinateY',['../main_8cpp.html#a3ebb4736fe140925dfc66dbccaa74378',1,'main.cpp']]],
  ['coordinatez',['coordinateZ',['../main_8cpp.html#ab87955921e4797f1d8fe91de5a37f27a',1,'main.cpp']]]
];
