var searchData=
[
  ['_7ematrix',['~Matrix',['../class_matrix.html#a9b1c3627f573d78a2f08623fdfef990f',1,'Matrix']]],
  ['_7estackmatrix',['~stackMatrix',['../classstack_matrix.html#a0bbdaa5e69a1b844267f66e87962ab97',1,'stackMatrix']]]
];
