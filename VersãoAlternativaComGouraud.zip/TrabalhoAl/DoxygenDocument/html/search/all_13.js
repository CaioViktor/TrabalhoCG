var searchData=
[
  ['w',['w',['../class_vertex.html#a670fe9a8416a863b89dab7442423af66',1,'Vertex']]]
];
