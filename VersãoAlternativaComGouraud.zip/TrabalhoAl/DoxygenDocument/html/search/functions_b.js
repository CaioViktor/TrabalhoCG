var searchData=
[
  ['printmatrix',['printMatrix',['../class_matrix.html#aa1967ad240a5ffaf492800044b7275d9',1,'Matrix']]],
  ['pull',['pull',['../classstack_matrix.html#a8566ffc86eae437403a9484f5c2a32fe',1,'stackMatrix']]],
  ['push',['push',['../classstack_matrix.html#af46ba624157a0536c295f2b1810e5277',1,'stackMatrix']]],
  ['pushinstack',['pushInStack',['../main_8cpp.html#a4110c9948ef8842756da48feaaff8160',1,'main.cpp']]]
];
