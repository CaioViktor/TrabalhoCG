var searchData=
[
  ['stackmatrix_2ecpp',['stackMatrix.cpp',['../stack_matrix_8cpp.html',1,'']]],
  ['stackmatrix_2eh',['stackMatrix.h',['../stack_matrix_8h.html',1,'']]]
];
