var searchData=
[
  ['partialstacktransformation',['partialStackTransformation',['../main_8cpp.html#aa0d19c8bbab6cc6d9c34dd0076bbc85e',1,'main.cpp']]],
  ['partialtransformationmatrix',['partialTransformationMatrix',['../main_8cpp.html#abb551773ee878a6bafebf9bddacf1f9d',1,'main.cpp']]]
];
