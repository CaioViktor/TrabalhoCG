var searchData=
[
  ['face',['Face',['../class_face.html#afdb634bc2d5287ba0d62e46b57e9dc2e',1,'Face::Face()'],['../class_face.html#a21efca31beed80f6b81bb520f5ccef6d',1,'Face::Face(Vertex *vertice1, Vertex *vertice2, Vertex *vertice3)']]]
];
