var searchData=
[
  ['readme',['README',['../md__c_1__users__matheus__documents__git_hub__trabalho_c_g__r_e_a_d_m_e.html',1,'']]],
  ['r',['R',['../class_object_class.html#aa60cb233d9456152e953bed66d84b3a7',1,'ObjectClass']]],
  ['radians',['radians',['../main_8cpp.html#a48f677a2de2617a4ea7aa63f51692fb7',1,'main.cpp']]],
  ['readme_2emd',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['render',['render',['../main_8cpp.html#a7d9edd8b0a8d0d2f737eb5ee0b0a5040',1,'main.cpp']]],
  ['reshape',['reshape',['../main_8cpp.html#acc1ffe65e6869931318610cae7210078',1,'main.cpp']]]
];
