var searchData=
[
  ['stackmatrix',['stackMatrix',['../classstack_matrix.html',1,'']]]
];
