var searchData=
[
  ['numberfaces',['numberFaces',['../class_list_face.html#af94f2d60855574140e7fb46ac16428e8',1,'ListFace']]],
  ['numbervertex',['numberVertex',['../class_list_vertex.html#a0fa7cf40012232cceca046e43546620a',1,'ListVertex']]]
];
