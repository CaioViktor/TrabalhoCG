#include <stdlib.h>
int main(){
	system("firefox DoxygenDocument/html/index.html");
}