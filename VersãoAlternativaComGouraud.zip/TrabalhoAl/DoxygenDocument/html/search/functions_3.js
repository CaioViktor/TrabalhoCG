var searchData=
[
  ['earquivoobj',['eArquivoObj',['../class_leitor.html#a475a98fb938689368d6529ef9ed42512',1,'Leitor']]]
];
