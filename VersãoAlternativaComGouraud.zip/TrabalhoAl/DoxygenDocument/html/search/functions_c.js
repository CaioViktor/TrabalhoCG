var searchData=
[
  ['render',['render',['../main_8cpp.html#a7d9edd8b0a8d0d2f737eb5ee0b0a5040',1,'main.cpp']]],
  ['reshape',['reshape',['../main_8cpp.html#acc1ffe65e6869931318610cae7210078',1,'main.cpp']]]
];
