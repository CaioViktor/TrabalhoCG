var searchData=
[
  ['updatecentroide',['updateCentroide',['../class_object_class.html#a19b72d6d31df6474414288da1d5cdda3',1,'ObjectClass']]]
];
